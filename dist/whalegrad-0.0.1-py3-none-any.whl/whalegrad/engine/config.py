from whalegrad.engine.base.graph import Graph
global GRAPH_GB
GRAPH_GB = Graph()

