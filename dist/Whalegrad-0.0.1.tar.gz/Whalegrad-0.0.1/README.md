# whalegrad 🐳
# WhaleGrad a deep learning framework based on Python and NumPy with experimental Jax integration.
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

![](https://github.com/saurabhaloneai/whalegrad/blob/main/images/whalegrad.png)

# Whalor

* It is multi-dim array like  Whalor.
* It support float, int numpy-array and list.


